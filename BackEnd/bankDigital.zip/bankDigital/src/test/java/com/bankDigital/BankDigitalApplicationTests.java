package com.bankDigital;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BankDigitalApplicationTests {

	@Test
	void contextLoads() {
	}

}
