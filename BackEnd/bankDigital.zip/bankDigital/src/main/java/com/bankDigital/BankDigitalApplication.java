package com.bankDigital;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BankDigitalApplication {

	public static void main(String[] args) {
		SpringApplication.run(BankDigitalApplication.class, args);
	}

}
